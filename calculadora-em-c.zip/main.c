#include <stdio.h>
float x=0,y=0,resultado=0;
int op=0;
int main(void) {
  do{
  printf("\n\t1 SOMA\n\t2 SUBTRACAO-\n\t3 MULTIPLICACAO \n\t4 DIVISAO");
  scanf("%i",&op);

  printf("digite o primeiro numero:\n");
  scanf("%f",&x);

  printf("digite o segundo numero:\n");
  scanf("%f",&y);
  switch (op){
  case 1:
  resultado=x+y;
  break;
  case 2:
  resultado = x-y;
  break;
  case 3:
  resultado = x*y;
  break;
  case 4:
  resultado =x/y;
  break;
  default:
  printf("digite uma operacao valida:\n");
  break;  
  }
  printf("\n\t o resultado e:%0.2f\n",resultado);
  printf("para continuar digite 1 ou qualquer outro numero para sair\n");
  scanf("%i",&op);


  }while(op==1);
  return 0;
}